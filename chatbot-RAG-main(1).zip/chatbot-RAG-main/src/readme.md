This directory contains the gradio app and its helper functions
