"""
This file contains the path of the knowledge base and the model name. All paths are relative to the root directory of the project.
"""

KNOWLEDGE_BASE_PATH = 'KnowledgeDocument(pan_card_services).txt'
MODEL_NAME = 'gpt-3.5-turbo-0301'
